package com.biz.rbooks.config;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MybatisConfig {
	
	@Bean
	public DataSource oracleDs() {
		BasicDataSource ds = new BasicDataSource();
		ds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		ds.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		ds.setUsername("bookuser");
		ds.setPassword("1234");
		return ds;
	}
	
	@Bean
	public SqlSessionFactoryBean sqlFactory() {
		SqlSessionFactoryBean sb = new SqlSessionFactoryBean();
		return sb;
	}
}
