package com.biz.rbooks.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RootConfig {

}
